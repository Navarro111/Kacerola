import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyApFU69xB_tbScy1pVtKnZrol84dFSEoQk",
  authDomain: "kacerola-crud.firebaseapp.com",
  projectId: "kacerola-crud",
  storageBucket: "kacerola-crud.firebasestorage.app",
  messagingSenderId: "153091127469",
  appId: "1:153091127469:web:3fdcfafb19c1cb5ab92e24"
};

const app = initializeApp(firebaseConfig);

export const DATABASES = {
  chiriqui: {
    id: "db-chiriqui",
    label: "Chiriquí"
  },
  panama: {
    id: "db-panama",
    label: "Panamá"
  },
  chitre: {
    id: "db-chitre",
    label: "Chitré"
  }
};

export const dbInstances = {
  chiriqui: getFirestore(app, DATABASES.chiriqui.id),
  panama: getFirestore(app, DATABASES.panama.id),
  chitre: getFirestore(app, DATABASES.chitre.id)
};

export function getDbBySucursal(sucursalKey) {
  const db = dbInstances[sucursalKey];

  if (!db) {
    throw new Error(`No existe una base de datos configurada para la sucursal: ${sucursalKey}`);
  }

  return db;
}

export function getSucursalMeta(sucursalKey) {
  return DATABASES[sucursalKey] ?? null;
}

export { app, firebaseConfig };
