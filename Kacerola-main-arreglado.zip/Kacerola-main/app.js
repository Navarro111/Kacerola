import {
  collection,
  addDoc,
  onSnapshot,
  updateDoc,
  deleteDoc,
  doc,
  setDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

import {
  DATABASES,
  dbInstances,
  getDbBySucursal,
  getSucursalMeta
} from "./firebaseConfig.js";

/* ======================================================
   1) REFERENCIAS DEL DOM
   ====================================================== */
const gastoForm = document.getElementById("gastoForm");
const sucursal = document.getElementById("sucursal");
const categoria = document.getElementById("categoria");
const periodicidad = document.getElementById("periodicidad");
const fecha = document.getElementById("fecha");
const dia = document.getElementById("dia");
const cantidad = document.getElementById("cantidad");
const rubros = document.getElementById("rubros");
const otros = document.getElementById("otros");

const btnGuardar = document.getElementById("btnGuardar");
const btnCancelar = document.getElementById("btnCancelar");

const filtroCategoria = document.getElementById("filtroCategoria");
const filtroSucursal = document.getElementById("filtroSucursal");
const btnLimpiarFiltros = document.getElementById("btnLimpiarFiltros");

const tablaGastos = document.getElementById("tablaGastos");
const mensaje = document.getElementById("mensaje");
const totalGastos = document.getElementById("totalGastos");
const cantidadRegistros = document.getElementById("cantidadRegistros");

/* ======================================================
   2) ESTADO DE LA APP
   ====================================================== */
let gastos = [];
let gastosPorSucursal = {
  chiriqui: [],
  panama: [],
  chitre: []
};
let editandoId = null;
let editandoDbKey = null;
let unsubscribeListeners = [];

/* ======================================================
   3) FUNCIONES AUXILIARES
   ====================================================== */
function mostrarMensaje(texto, tipo = "success") {
  mensaje.textContent = texto;
  mensaje.className = `mensaje ${tipo}`;

  setTimeout(() => {
    mensaje.className = "mensaje oculto";
    mensaje.textContent = "";
  }, 3500);
}

function limpiarFormulario() {
  gastoForm.reset();
  dia.value = "";
  editandoId = null;
  editandoDbKey = null;
  btnGuardar.textContent = "Guardar gasto";
  btnCancelar.classList.add("oculto");
}

function obtenerDiaEnEspanol(fechaTexto) {
  if (!fechaTexto) return "";

  const dias = [
    "Domingo",
    "Lunes",
    "Martes",
    "Miércoles",
    "Jueves",
    "Viernes",
    "Sábado"
  ];

  const fechaObj = new Date(`${fechaTexto}T00:00:00`);
  return dias[fechaObj.getDay()];
}

function validarCampos() {
  if (
    !sucursal.value.trim() ||
    !categoria.value.trim() ||
    !periodicidad.value.trim() ||
    !fecha.value.trim() ||
    !dia.value.trim() ||
    !cantidad.value.trim() ||
    !rubros.value.trim() ||
    !otros.value.trim()
  ) {
    mostrarMensaje("Todos los campos son obligatorios. No pueden quedar vacíos.", "error");
    return false;
  }

  if (!getSucursalMeta(sucursal.value)) {
    mostrarMensaje("La sucursal seleccionada no tiene una base de datos configurada.", "error");
    return false;
  }

  const monto = parseFloat(cantidad.value);
  if (isNaN(monto) || monto <= 0) {
    mostrarMensaje("La cantidad debe ser un número mayor que 0.", "error");
    return false;
  }

  return true;
}

function obtenerDatosFormulario() {
  const sucursalKey = sucursal.value.trim();
  const sucursalMeta = getSucursalMeta(sucursalKey);

  return {
    sucursal: sucursalMeta.label,
    sucursalKey,
    databaseId: sucursalMeta.id,
    categoria: categoria.value.trim(),
    periodicidad: periodicidad.value.trim(),
    fecha: fecha.value,
    dia: dia.value.trim(),
    cantidad: parseFloat(cantidad.value),
    rubros: rubros.value.trim(),
    otros: otros.value.trim(),
    updatedAt: serverTimestamp()
  };
}

function escaparHTML(valor) {
  if (valor === null || valor === undefined) return "";
  return String(valor)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function aplicarFiltros(lista) {
  let resultado = [...lista];

  if (filtroCategoria.value !== "Todas") {
    resultado = resultado.filter((item) => item.categoria === filtroCategoria.value);
  }

  if (filtroSucursal.value !== "Todas") {
    resultado = resultado.filter((item) => item.dbKey === filtroSucursal.value);
  }

  return resultado;
}

function actualizarResumen(lista) {
  const total = lista.reduce((acc, item) => acc + Number(item.cantidad || 0), 0);
  totalGastos.textContent = `B/. ${total.toFixed(2)}`;
  cantidadRegistros.textContent = lista.length;
}

function renderizarTabla() {
  const listaFiltrada = aplicarFiltros(gastos);
  actualizarResumen(listaFiltrada);

  if (listaFiltrada.length === 0) {
    tablaGastos.innerHTML = `
      <tr>
        <td colspan="9" class="empty">No hay registros para mostrar.</td>
      </tr>
    `;
    return;
  }

  tablaGastos.innerHTML = listaFiltrada
    .map(
      (item) => `
        <tr>
          <td>${escaparHTML(item.sucursal)}</td>
          <td><span class="badge">${escaparHTML(item.categoria)}</span></td>
          <td>${escaparHTML(item.periodicidad)}</td>
          <td>${escaparHTML(item.fecha)}</td>
          <td>${escaparHTML(item.dia)}</td>
          <td>B/. ${Number(item.cantidad).toFixed(2)}</td>
          <td>${escaparHTML(item.rubros)}</td>
          <td>${escaparHTML(item.otros)}</td>
          <td>
            <div class="actions">
              <button class="btn warning btn-editar" data-id="${item.id}" data-db-key="${item.dbKey}">Editar</button>
              <button class="btn danger btn-eliminar" data-id="${item.id}" data-db-key="${item.dbKey}">Eliminar</button>
            </div>
          </td>
        </tr>
      `
    )
    .join("");
}

function cargarDatosEnFormulario(item) {
  sucursal.value = item.dbKey;
  categoria.value = item.categoria;
  periodicidad.value = item.periodicidad;
  fecha.value = item.fecha;
  dia.value = item.dia;
  cantidad.value = Number(item.cantidad).toFixed(2);
  rubros.value = item.rubros;
  otros.value = item.otros;

  editandoId = item.id;
  editandoDbKey = item.dbKey;
  btnGuardar.textContent = "Actualizar gasto";
  btnCancelar.classList.remove("oculto");

  document.getElementById("formulario-section").scrollIntoView({ behavior: "smooth" });
}

function normalizarGasto(docu, dbKey) {
  const data = docu.data();
  const sucursalMeta = getSucursalMeta(dbKey);

  return {
    id: docu.id,
    dbKey,
    databaseId: sucursalMeta.id,
    sucursal: sucursalMeta.label,
    ...data,
    sucursalKey: dbKey
  };
}

function actualizarListadoGeneral() {
  gastos = Object.values(gastosPorSucursal)
    .flat()
    .sort((a, b) => (b.fecha || "").localeCompare(a.fecha || ""));

  renderizarTabla();
}

function obtenerGastoActual(id, dbKey) {
  return gastos.find((item) => item.id === id && item.dbKey === dbKey) ?? null;
}

/* ======================================================
   4) EVENTOS
   ====================================================== */
fecha.addEventListener("change", () => {
  dia.value = obtenerDiaEnEspanol(fecha.value);
});

gastoForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  if (!validarCampos()) return;

  try {
    const datos = obtenerDatosFormulario();
    const dbDestino = getDbBySucursal(datos.sucursalKey);
    const gastosRefDestino = collection(dbDestino, "gastos");

    if (editandoId && editandoDbKey) {
      const dbOrigen = getDbBySucursal(editandoDbKey);
      const docRefOrigen = doc(dbOrigen, "gastos", editandoId);
      const docRefDestino = doc(dbDestino, "gastos", editandoId);
      const gastoOriginal = obtenerGastoActual(editandoId, editandoDbKey);
      const cambioDeBase = editandoDbKey !== datos.sucursalKey;

      if (cambioDeBase) {
        await setDoc(docRefDestino, {
          ...datos,
          createdAt: gastoOriginal?.createdAt ?? serverTimestamp()
        });
        await deleteDoc(docRefOrigen);
        mostrarMensaje("Gasto movido y actualizado correctamente en la nueva base de datos.", "success");
      } else {
        await updateDoc(docRefOrigen, datos);
        mostrarMensaje("Gasto actualizado correctamente.", "success");
      }
    } else {
      await addDoc(gastosRefDestino, {
        ...datos,
        createdAt: serverTimestamp()
      });
      mostrarMensaje("Gasto guardado correctamente en la base de datos de la sucursal.", "success");
    }

    limpiarFormulario();
  } catch (error) {
    console.error("Error al guardar/actualizar:", error);
    mostrarMensaje(`Error al procesar la operación: ${error.message}`, "error");
  }
});

btnCancelar.addEventListener("click", () => {
  limpiarFormulario();
  mostrarMensaje("Edición cancelada.", "warning");
});

filtroCategoria.addEventListener("change", renderizarTabla);
filtroSucursal.addEventListener("change", renderizarTabla);

btnLimpiarFiltros.addEventListener("click", (e) => {
  e.preventDefault();
  filtroCategoria.value = "Todas";
  filtroSucursal.value = "Todas";
  renderizarTabla();
  mostrarMensaje("Filtros limpiados.", "success");
});

tablaGastos.addEventListener("click", async (e) => {
  const botonEditar = e.target.closest(".btn-editar");
  const botonEliminar = e.target.closest(".btn-eliminar");

  if (botonEditar) {
    const id = botonEditar.dataset.id;
    const dbKey = botonEditar.dataset.dbKey;
    const gasto = obtenerGastoActual(id, dbKey);

    if (gasto) {
      cargarDatosEnFormulario(gasto);
    }
  }

  if (botonEliminar) {
    const id = botonEliminar.dataset.id;
    const dbKey = botonEliminar.dataset.dbKey;
    const confirmar = confirm("¿Seguro que deseas eliminar este gasto?");

    if (!confirmar) return;

    try {
      const db = getDbBySucursal(dbKey);
      await deleteDoc(doc(db, "gastos", id));
      mostrarMensaje("Gasto eliminado correctamente.", "success");

      if (editandoId === id && editandoDbKey === dbKey) {
        limpiarFormulario();
      }
    } catch (error) {
      console.error("Error al eliminar:", error);
      mostrarMensaje(`Error al eliminar: ${error.message}`, "error");
    }
  }
});

/* ======================================================
   5) LECTURA EN TIEMPO REAL DESDE LAS 3 BASES DE DATOS
   ====================================================== */
function escucharGastosEnTiempoReal() {
  unsubscribeListeners.forEach((unsubscribe) => unsubscribe());
  unsubscribeListeners = [];

  Object.keys(dbInstances).forEach((dbKey) => {
    const db = getDbBySucursal(dbKey);
    const gastosRef = collection(db, "gastos");

    const unsubscribe = onSnapshot(
      gastosRef,
      (snapshot) => {
        gastosPorSucursal[dbKey] = snapshot.docs.map((docu) => normalizarGasto(docu, dbKey));
        actualizarListadoGeneral();
      },
      (error) => {
        console.error(`Error en tiempo real para ${dbKey}:`, error);
        mostrarMensaje(`Error al leer datos de ${dbKey}: ${error.message}`, "error");
      }
    );

    unsubscribeListeners.push(unsubscribe);
  });
}

/* ======================================================
   6) INICIO
   ====================================================== */
escucharGastosEnTiempoReal();
